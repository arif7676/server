-- phpMyAdmin SQL Dump
-- version 4.1.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 23 Des 2016 pada 07.04
-- Versi Server: 5.6.34-log
-- PHP Version: 5.5.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `570287280_sms`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_absensi`
--

CREATE TABLE IF NOT EXISTS `tbl_absensi` (
  `id_absensi` int(225) NOT NULL AUTO_INCREMENT,
  `nip` varchar(100) NOT NULL,
  `nis` varchar(100) NOT NULL,
  `kode_mapel` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `tgl_absensi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_absensi`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data untuk tabel `tbl_absensi`
--

INSERT INTO `tbl_absensi` (`id_absensi`, `nip`, `nis`, `kode_mapel`, `status`, `tgl_absensi`) VALUES
(6, '0712345', '130403020059', 'BI', 'Hadir', '2016-11-07 06:31:46'),
(7, '0712345', '130403020033', 'AG', 'Hadir', '2016-11-07 06:31:52');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail_jadwal`
--

CREATE TABLE IF NOT EXISTS `tbl_detail_jadwal` (
  `id_jadwal` int(225) NOT NULL AUTO_INCREMENT,
  `nip` varchar(100) NOT NULL,
  `nis` varchar(100) NOT NULL,
  `kode_kelas` varchar(100) NOT NULL,
  `kode_mapel` varchar(100) NOT NULL,
  `hari` varchar(100) NOT NULL,
  `img_jadwal` varchar(100) NOT NULL,
  PRIMARY KEY (`id_jadwal`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data untuk tabel `tbl_detail_jadwal`
--

INSERT INTO `tbl_detail_jadwal` (`id_jadwal`, `nip`, `nis`, `kode_kelas`, `kode_mapel`, `hari`, `img_jadwal`) VALUES
(36, '0712352', '130403020035', 'K01A', 'BI', 'Saptu', 'ic_jadwal.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail_nilai`
--

CREATE TABLE IF NOT EXISTS `tbl_detail_nilai` (
  `id_nilai` int(225) NOT NULL AUTO_INCREMENT,
  `nip` varchar(100) NOT NULL,
  `nis` varchar(100) NOT NULL,
  `kode_mapel` varchar(100) NOT NULL,
  `nilai_uh` varchar(100) NOT NULL,
  `nilai_tugas` varchar(100) NOT NULL,
  `nilai_uts` varchar(100) NOT NULL,
  `nilai_uas` varchar(100) NOT NULL,
  `nilai_akhir` varchar(100) NOT NULL,
  `img_nilai` varchar(100) NOT NULL,
  PRIMARY KEY (`id_nilai`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data untuk tabel `tbl_detail_nilai`
--

INSERT INTO `tbl_detail_nilai` (`id_nilai`, `nip`, `nis`, `kode_mapel`, `nilai_uh`, `nilai_tugas`, `nilai_uts`, `nilai_uas`, `nilai_akhir`, `img_nilai`) VALUES
(1, '0712345', '130403020059', 'BI', '100', '100', '100', '100', '100', 'ic_nilai.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_detail_ujian`
--

CREATE TABLE IF NOT EXISTS `tbl_detail_ujian` (
  `id_ujian` int(225) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(100) NOT NULL,
  `kode_mapel` varchar(100) NOT NULL,
  `tgl_ujian` varchar(100) NOT NULL,
  `jam_mulai` varchar(100) NOT NULL,
  `jam_selesai` varchar(100) NOT NULL,
  `ket` varchar(100) NOT NULL,
  `img_ujian` varchar(100) NOT NULL,
  PRIMARY KEY (`id_ujian`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data untuk tabel `tbl_detail_ujian`
--

INSERT INTO `tbl_detail_ujian` (`id_ujian`, `kode_kelas`, `kode_mapel`, `tgl_ujian`, `jam_mulai`, `jam_selesai`, `ket`, `img_ujian`) VALUES
(9, 'K01A', 'IPS', '22-12-2016', '07.00', '09.00', 'Ujian Tengah Semester', 'ic_ujian.png'),
(10, 'K01A', 'PKN', '22-12-2016', '09.30', '10.20', 'Ujian Tengah Semester', 'ic_ujian.png'),
(11, 'K01A', 'BIO', '23-12-2016', '07.00', '09.00', 'Ujian Tengah Semester', 'ic_ujian.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_guru`
--

CREATE TABLE IF NOT EXISTS `tbl_guru` (
  `id_guru` int(225) NOT NULL AUTO_INCREMENT,
  `nip` varchar(100) NOT NULL,
  `nama_guru` varchar(100) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `no_telp` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id_guru`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data untuk tabel `tbl_guru`
--

INSERT INTO `tbl_guru` (`id_guru`, `nip`, `nama_guru`, `alamat`, `no_telp`, `password`) VALUES
(10, '0712353', 'Arum Sulis', 'Kepanjen Malang', '08977766234', 'arum');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_kelas`
--

CREATE TABLE IF NOT EXISTS `tbl_kelas` (
  `id_kelas` int(225) NOT NULL AUTO_INCREMENT,
  `kode_kelas` varchar(100) NOT NULL,
  `kelas` varchar(100) NOT NULL,
  `sub_kelas` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kelas`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data untuk tabel `tbl_kelas`
--

INSERT INTO `tbl_kelas` (`id_kelas`, `kode_kelas`, `kelas`, `sub_kelas`) VALUES
(1, 'K01A', '1', 'A');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_mapel`
--

CREATE TABLE IF NOT EXISTS `tbl_mapel` (
  `id_mapel` int(225) NOT NULL AUTO_INCREMENT,
  `kode_mapel` varchar(100) NOT NULL,
  `mapel` varchar(100) NOT NULL,
  `jam_mulai` varchar(100) NOT NULL,
  `jam_selesai` varchar(100) NOT NULL,
  PRIMARY KEY (`id_mapel`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data untuk tabel `tbl_mapel`
--

INSERT INTO `tbl_mapel` (`id_mapel`, `kode_mapel`, `mapel`, `jam_mulai`, `jam_selesai`) VALUES
(11, 'BIO', 'Biologi', '07.00', '09.30'),
(12, 'IST', 'Istirahat', '09.30', '10.00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pengumuman`
--

CREATE TABLE IF NOT EXISTS `tbl_pengumuman` (
  `id_p` int(225) NOT NULL AUTO_INCREMENT,
  `judul` varchar(100) NOT NULL,
  `detail` varchar(1000) NOT NULL,
  `tgl` varchar(100) NOT NULL,
  `img_p` varchar(100) NOT NULL,
  PRIMARY KEY (`id_p`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data untuk tabel `tbl_pengumuman`
--

INSERT INTO `tbl_pengumuman` (`id_p`, `judul`, `detail`, `tgl`, `img_p`) VALUES
(20, 'Liburan UTS', 'Libur uts di laksanakan pada tgl 18-3-2017 sampai 22-3-2017', '18-03-2016', 'ic_pengumuman.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_siswa`
--

CREATE TABLE IF NOT EXISTS `tbl_siswa` (
  `id_siswa` int(225) NOT NULL AUTO_INCREMENT,
  `nis` varchar(100) NOT NULL,
  `nama_siswa` varchar(100) NOT NULL,
  `kode_kelas` varchar(10) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `nip` varchar(100) NOT NULL,
  `tgl_lahir` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `img_siswa` varchar(100) NOT NULL,
  PRIMARY KEY (`id_siswa`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data untuk tabel `tbl_siswa`
--

INSERT INTO `tbl_siswa` (`id_siswa`, `nis`, `nama_siswa`, `kode_kelas`, `no_telp`, `alamat`, `nip`, `tgl_lahir`, `password`, `img_siswa`) VALUES
(19, '130403020050', 'Fiil Anam', 'K01B', '085788676443', 'Kebonagung Malang', '0712344', '12-4-1997', 'fiil', 'fiil.png'),
(20, '130403020051', 'Ida Wati', 'K01B', '085778976345', 'Dampit Malang', '0712344', '13-7-1997', 'idaw', 'ida.png');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
