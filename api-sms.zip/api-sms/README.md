# api-sms
Server API Sistem Sekolahan V.0.1

# Download Sourcode Android SistemSekolah V.0.1
https://github.com/titoprogramer/SistemSekolah-Master

# Lisensi
Opensource ,Free download

# Alamat Server
http://project0.pe.hu/api-sms/

# Penting
Saya tidak meminta donasi berupa apapun, tapi saya minta kesadaran anda untuk menyertakan sumber asal jika ingin reupload atau share. Terimakasih 
