<?php
     define('HOST','mysql.idhostinger.com');
     define('USER',' u915235348_serve');
     define('PASS','1512015');
     define('DB',' 	u915235348_serve');
     
     $con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect');
?>
